var class_ya_server =
[
    [ "YaServer", "class_ya_server.html#a0dc363dff501ae69c607870d554222f0", null ],
    [ "operator=", "class_ya_server.html#ac5728f7bd48382f187562dfb6f991258", null ],
    [ "startServer", "class_ya_server.html#ab1eb91646133987b866a88d0e2804d23", null ]
];