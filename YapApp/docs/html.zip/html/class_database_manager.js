var class_database_manager =
[
    [ "addContact", "class_database_manager.html#aaa65a69d209e20b4b8464418d610eb4f", null ],
    [ "authenticateUser", "class_database_manager.html#a42d1f36765b1a6fedffbece2d0143009", null ],
    [ "connect", "class_database_manager.html#a3cbc0c691ef2b9e7851a33959817dee6", null ],
    [ "getChatMessages", "class_database_manager.html#aedb854056fd7a83c58ab19b61c41195a", null ],
    [ "getUserById", "class_database_manager.html#a7ec65dd93603e103657ca40f1cd69dc0", null ],
    [ "getUserByUsername", "class_database_manager.html#a4aa110527206a1efbc51d1456cbe51ea", null ],
    [ "getUserContacts", "class_database_manager.html#a24a0a309990142d639a6429e4a18eaf2", null ],
    [ "getUserMessages", "class_database_manager.html#a554a7487da54b3c5a4dad2af167a5f0e", null ],
    [ "initDatabaseSchema", "class_database_manager.html#aa3c02205a9ddce62e9f5b904375a2112", null ],
    [ "isConnected", "class_database_manager.html#aa4191649a436b20af9d2151e141ee148", null ],
    [ "markMessageAsRead", "class_database_manager.html#a38ab42b522a0f826c6c2fc9e22cb0b8b", null ],
    [ "registerUser", "class_database_manager.html#a510a374b1af52a5884da5d5841f78906", null ],
    [ "sendMessage", "class_database_manager.html#a4ec1070ffe5d42b7215db8f2ea335a51", null ]
];