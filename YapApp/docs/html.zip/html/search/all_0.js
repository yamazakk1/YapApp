var searchData=
[
  ['addcontact_0',['addContact',['../class_database_manager.html#aaa65a69d209e20b4b8464418d610eb4f',1,'DatabaseManager']]],
  ['authenticateuser_1',['authenticateUser',['../class_database_manager.html#a42d1f36765b1a6fedffbece2d0143009',1,'DatabaseManager']]]
];
