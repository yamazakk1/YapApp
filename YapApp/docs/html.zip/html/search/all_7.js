var searchData=
[
  ['markmessageasread_0',['markMessageAsRead',['../class_database_manager.html#a38ab42b522a0f826c6c2fc9e22cb0b8b',1,'DatabaseManager']]],
  ['method_1',['method',['../class_http_request.html#a582879b54bca44ce4d6a7413f03ad95b',1,'HttpRequest']]]
];
