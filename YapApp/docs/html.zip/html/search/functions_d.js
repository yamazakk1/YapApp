var searchData=
[
  ['user_0',['User',['../class_user.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../class_user.html#a16d5efee6e82076e5f4cf91442680780',1,'User::User(QString firstName, QString lastName, QString email)']]]
];
