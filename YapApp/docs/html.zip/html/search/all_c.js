var searchData=
[
  ['registeruser_0',['registerUser',['../class_database_manager.html#a510a374b1af52a5884da5d5841f78906',1,'DatabaseManager']]]
];
