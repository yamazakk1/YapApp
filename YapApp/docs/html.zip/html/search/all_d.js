var searchData=
[
  ['sendmessage_0',['sendMessage',['../class_database_manager.html#a4ec1070ffe5d42b7215db8f2ea335a51',1,'DatabaseManager']]],
  ['setemail_1',['setEmail',['../class_user.html#a089c2c4126ed0888fb1aa715371b942c',1,'User']]],
  ['setfirstname_2',['setFirstName',['../class_user.html#ae5c68644d996c177e9df403c1001cf17',1,'User']]],
  ['setlastname_3',['setLastName',['../class_user.html#ae1eb7c2a1e4e201e553bf659455ca1c8',1,'User']]],
  ['startserver_4',['startServer',['../class_ya_server.html#ab1eb91646133987b866a88d0e2804d23',1,'YaServer']]]
];
