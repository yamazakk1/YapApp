var searchData=
[
  ['connect_0',['connect',['../class_database_manager.html#a3cbc0c691ef2b9e7851a33959817dee6',1,'DatabaseManager']]]
];
