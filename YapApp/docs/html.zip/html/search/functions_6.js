var searchData=
[
  ['markmessageasread_0',['markMessageAsRead',['../class_database_manager.html#a38ab42b522a0f826c6c2fc9e22cb0b8b',1,'DatabaseManager']]]
];
