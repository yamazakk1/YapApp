var searchData=
[
  ['yahttpserver_0',['YaHttpServer',['../class_ya_http_server.html',1,'YaHttpServer'],['../class_ya_http_server.html#ae58db031020148ffaa82ffc6a9cac4c2',1,'YaHttpServer::YaHttpServer()']]],
  ['yaserver_1',['YaServer',['../class_ya_server.html',1,'YaServer'],['../class_ya_server.html#a0dc363dff501ae69c607870d554222f0',1,'YaServer::YaServer()']]]
];
