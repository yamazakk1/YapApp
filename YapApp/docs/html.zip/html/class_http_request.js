var class_http_request =
[
    [ "header", "class_http_request.html#af590e0861647a28195c9f6848eb0608a", null ],
    [ "isValid", "class_http_request.html#a1c9b12924e92a83aee5f294478681fa6", null ],
    [ "query", "class_http_request.html#ac319156abd67abd1877a59fa14248fab", null ],
    [ "body", "class_http_request.html#a7b1e70e05f55cb477134b55766e103cc", null ],
    [ "headers", "class_http_request.html#aae0d21d006655c2e206b2417bcbfca78", null ],
    [ "method", "class_http_request.html#a582879b54bca44ce4d6a7413f03ad95b", null ],
    [ "path", "class_http_request.html#aa67a067141184695df61f3db9b07ca76", null ],
    [ "queryParams", "class_http_request.html#ab2b0412188c3d3baf90598de7489d345", null ],
    [ "valid", "class_http_request.html#a962e1ce65ef7b09609c7df89516567a1", null ]
];