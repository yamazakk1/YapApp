var annotated_dup =
[
    [ "DatabaseManager", "class_database_manager.html", "class_database_manager" ],
    [ "HttpRequest", "class_http_request.html", "class_http_request" ],
    [ "User", "class_user.html", "class_user" ],
    [ "YaHttpServer", "class_ya_http_server.html", "class_ya_http_server" ],
    [ "YaServer", "class_ya_server.html", "class_ya_server" ]
];