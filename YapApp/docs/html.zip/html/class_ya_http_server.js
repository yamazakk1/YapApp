var class_ya_http_server =
[
    [ "YaHttpServer", "class_ya_http_server.html#ae58db031020148ffaa82ffc6a9cac4c2", null ],
    [ "disconnect", "class_ya_http_server.html#a885943f74ad3150c7e0cf713008bff7a", null ],
    [ "incomingConnection", "class_ya_http_server.html#a788a65b85fd8f295e4d7f58c81f0a45b", null ],
    [ "newRequest", "class_ya_http_server.html#a1fa03900ccab50b59e8192a3a901a50c", null ]
];