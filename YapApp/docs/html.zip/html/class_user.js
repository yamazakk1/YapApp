var class_user =
[
    [ "User", "class_user.html#a4a0137053e591fbb79d9057dd7d2283d", null ],
    [ "User", "class_user.html#a16d5efee6e82076e5f4cf91442680780", null ],
    [ "getEmail", "class_user.html#a080b4119344d333a59d14bd5d0667797", null ],
    [ "getFirstName", "class_user.html#a86d1ab75ca7c4ad813ae72b43297fb35", null ],
    [ "getLastName", "class_user.html#a9864f7521f7f0bf8132e2464e9df7a02", null ],
    [ "setEmail", "class_user.html#a089c2c4126ed0888fb1aa715371b942c", null ],
    [ "setFirstName", "class_user.html#ae5c68644d996c177e9df403c1001cf17", null ],
    [ "setLastName", "class_user.html#ae1eb7c2a1e4e201e553bf659455ca1c8", null ]
];