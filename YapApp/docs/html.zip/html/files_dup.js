var files_dup =
[
    [ "database.h", "database_8h_source.html", null ],
    [ "httprequest.h", "httprequest_8h_source.html", null ],
    [ "user.h", "user_8h_source.html", null ],
    [ "yahttpserver.h", "yahttpserver_8h_source.html", null ],
    [ "yaserver.h", "yaserver_8h_source.html", null ]
];