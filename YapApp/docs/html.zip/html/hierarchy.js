var hierarchy =
[
    [ "HttpRequest", "class_http_request.html", null ],
    [ "QObject", null, [
      [ "DatabaseManager", "class_database_manager.html", null ],
      [ "YaServer", "class_ya_server.html", null ]
    ] ],
    [ "QTcpServer", null, [
      [ "YaHttpServer", "class_ya_http_server.html", null ]
    ] ],
    [ "User", "class_user.html", null ]
];